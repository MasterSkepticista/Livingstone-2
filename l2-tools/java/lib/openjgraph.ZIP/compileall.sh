# !/bin/sh

. ./setEnv.sh

echo "Compiling the OpenJGraph library and placing the classes under classes/ ..."
rm -rf classes/
mkdir classes
$JAVA_BIN/javac -deprecation -g -sourcepath . -classpath $CLASSPATH -d classes/ \
    com/graph/*.java \
    com/graph/listener/*.java \
    com/graph/adaptor/*.java \
    com/graph/algorithm/*.java \
    com/graph/java/awt/*.java \
    com/graph/java/awt/geom/*.java \
    com/graph/javax/swing/*.java \
    com/util/*.java \
    com/geom/*.java \
    com/graph/visual/*.java \
    com/graph/visual/layout/*.java \
    com/graph/visual/drawing/*.java \
    com/graph/xml/*.java \
	

echo
echo "Copying image files..."
mkdir classes/com/graph/visual/images
cp -vf com/graph/visual/images/* classes/com/graph/visual/images 

echo "Copying XGMML DTD file..."
cp -vf com/graph/xml/*.dtd classes/com/graph/xml

echo
echo "Compiling sample applications..."
$JAVA_BIN/javac -g -deprecation -sourcepath . -classpath $CLASSPATH -d classes/ examples/*.java

echo
echo "Creating JAR file..."
rm -rf dist/
mkdir dist
$JAVA_BIN/jar cvf dist/openjgraph.jar -C classes/ . 

cp LICENSE.* dist/
cp lib/*.jar dist/
