package com.graph;
 
import java.io.*;

/**
 * A vertex in a graph.
 *
 * @author		Jesus M. Salvo Jr.
 */
public interface Vertex extends LabeledGraphComponent {

}
