/*
 * Class.java
 *
 * Created on February 28, 2003, 12:06 PM
 */

package com.graph.visual;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.graph.VertexImpl;

/**
 *
 * @author  rgarcia
 */
public class MyGraphPanel extends GraphPanel {
   
    
     public MyGraphPanel(GraphPanelState gps, VisualGraph vgraph){
         super(gps,vgraph);
         
         //Forces JComponent to Register itself JPanel with
         //ToolTipManager
         //Could have also registered Panel directly with the ToolTipManager
         setToolTipText("");
     }
     
     
     public String getToolTipText(MouseEvent e){
         
        Point p = e.getPoint(); 
        
        VisualVertex vv = vgraph.getNode(p.x,p.y);
        
        if(vv != null){ return ((VertexImpl)vv.getVertex()).getObject().toString() ;}
        
        return null;
        
        
     }
     
     
    
}
