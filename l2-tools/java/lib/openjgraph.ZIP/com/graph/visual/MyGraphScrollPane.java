/*
 * MyGraphScrollPane.java
 *
 * Created on February 28, 2003, 12:12 PM
 */



package com.graph.visual;


import java.awt.*;
import javax.swing.*;


/**
 *
 * @author  rgarcia
 */
public class MyGraphScrollPane extends GraphScrollPane{
    
    
    public MyGraphScrollPane(GraphPanelState gps, VisualGraph vgraph){
        
        this.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        this.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        
        this.gpanel = new MyGraphPanel(gps,vgraph);
        
        this.gpanel.gpcontainer = this;
        super.init();  
    }
}
