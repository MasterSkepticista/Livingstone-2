/*
 * DOM Light - Copyright (C) 1999 Dyade
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL Dyade BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dyade shall not be
 * used in advertising or otherwise to promote the sale, use or other
 * dealings in this Software without prior written authorization from
 * Dyade.
 *
 * $Id: XMLElement.java,v 1.3 2000/03/21 08:21:37 tkormann Exp $
 * Author: Thierry.Kormann@sophia.inria.fr
 */

package fr.dyade.koala.xml.domlight;

import java.util.*;

/**
 * This class represents a single element in an XML document tree. Notice that
 * the child node list and the attribute list are created only if needed.
 *
 * @author Thierry.Kormann@sophia.inria.fr 
 */
public class XMLElement extends XMLNode {

    /** The name of this element. */
    protected String name;
    /** The attributes of this element. */
    protected Hashtable attributes;
    /** The child nodes of this element. */
    protected XMLNode [] children;
    /** The number of child nodes of this element. */
    protected int nchildren;

    /**
     * Constructs a new element with the specified name.
     * @param name the name of this element
     */
    public XMLElement() {
	this(null);
    }

    /**
     * Constructs a new element with the specified name.
     * @param name the name of this element
     */
    public XMLElement(String name) {
	this.name = name;
    }

    /**
     * Returns the  name of this element.
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the  name of this element to the specified value.
     * @param name the name of this element
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Returns the child node at the specified index.
     * @param index the index of child node
     * @exception ArrayIndexOutOfBoundsException if the index is negative or
     * greater than the current number of children of this node.  
     */
    public XMLNode getChild(int index) {
	return children[index];
    }

    /**
     * Returns the number of child nodes of this element.
     */
    public int getChildCount() {
	return nchildren;
    }

    /**
     * Sets the specified node at the specified index. The previous node at
     * that index is discarded. The index must be a value greater than or equal
     * to 0 and less than the current number of children.
     * @param node the node to set
     * @param index the index of the node
     * @exception ArrayIndexOutOfBoundsException if the index was invalid 
     */
    public void setChild(int index, XMLNode node) {
	prepareXMLNode(node);
	children[index] = node;
    }

    /**
     * Appends the specified node to the child list of this element.
     * @param node the node to append
     */
    public void appendChild(XMLNode node) {
	prepareXMLNode(node);
	children[nchildren++] = node;
	node.parent = this;
    }

    /**
     * Inserts at the specified index the specified node.
     * @param index the index of the node
     * @param node the node to insert
     */
    public void insertChild(int index, XMLNode node) {
	prepareXMLNode(node);
	if (index < nchildren) {
	    System.arraycopy(children, index, children, index+1, 
			     nchildren-index);
	}
	children[index] = node;
	nchildren++;
	node.parent = this;
    }

    /**
     * Removes the child node at the specified index.
     * @param node the node to remove
     */
    public void removeChild(int index) {
 	if (children != null) {
	    XMLNode node = children[index];
	    node.parent = null;
	    if (index+1 < nchildren) {
		System.arraycopy(children, index+1, children, index, 
				 nchildren-index-1);
	    }
	    nchildren--;
	    if (nchildren == 0) {
		children = null;
	    }
	}
    }

    /**
     * Ensures that the specified node can be added to this element.
     * @param node the node that will be added to this node
     */
    private void prepareXMLNode(XMLNode node) {
 	if (children == null) {
	    children = new XMLNode[4];
	}
	if (children.length == nchildren) {
	    XMLNode [] newnodes = new XMLNode[nchildren*2];
	    System.arraycopy(children, 0, newnodes, 0, nchildren);
	    children = newnodes;
	}
	XMLElement nparent = node.parent;
	if (nparent != null) {
	    for (int i=0; i < nparent.nchildren; ++i) {
		if (nparent.children[i] == node) {
		    nparent.removeChild(i);
		    break;
		}
	    }
	}
    }

    /**
     * Adds a new attribute. If an attribute with that name is already present
     * in the node, its value is changed to be that of the value parameter.
     * @param name the name of the attribute
     * @param value the value of the attribute
     */
    public void addAttribute(String name, String value) {
	if (attributes == null) {
	    attributes = new Hashtable(7);
	}
	attributes.put(name, value);
    }

    /**
     * Removes the attribute with the specified name.
     * @param name the name of the attribute to remove
     */
    public void removeAttribute(String name) {
	if (attributes != null) {
	    attributes.remove(name);
	}
    }

    /**
     * Gets the value of the attribute with the specified name or null if any.
     * @param name the name of the attribute
     */
    public String getAttribute(String name) {
	return (attributes == null)?null:(String) attributes.get(name);
    }

    /**
     * Returns a list of the attribute names of this element, or null if any.
     */
    public String [] getAttributes() {
	if (attributes == null) {
	    return null;
	} else {
	    String [] names = new String[attributes.size()];
	    Enumeration e = attributes.keys();
	    for (int i=0; e.hasMoreElements(); ++i) {
		names[i] = (String) e.nextElement();
	    }
	    return names;
	}
    }    
}
