/*
 * DOM Light - Copyright (C) 1999 Dyade
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL Dyade BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dyade shall not be
 * used in advertising or otherwise to promote the sale, use or other
 * dealings in this Software without prior written authorization from
 * Dyade.
 *
 * $Id: XMLElementDeserializer.java,v 1.2 1999/11/03 17:57:26 tkormann Exp $
 * Author: Thierry.Kormann@sophia.inria.fr
 */

package fr.dyade.koala.xml.domlight;

import java.io.*;
import org.xml.sax.*;
import java.util.Hashtable;

/**
 * This class enables to create an <code>XMLElement</code> from an
 * InputStream. A SAX parser is used to parse and create the node.
 *
 * @author Thierry.Kormann@sophia.inria.fr 
 */
public class XMLElementDeserializer {
    
    // The default factory can be defined as a singleton. */
    static XMLElementFactory defaultFactory = new XMLElementFactoryImp();
    /** The input stream. */
    protected InputStream istream;
    /** The element factory used to create XMLElement or subclasses. */
    protected XMLElementFactory factory;
    /** The root node of the XML document. */
    private XMLElement rootNode;

    /**
     * Constructs a new deserializer for the specified input stream.
     * @param istream the input stream
     */
    public XMLElementDeserializer(InputStream istream) {
	this(istream, defaultFactory);
    }

    /**
     * Constructs a new deserializer for the specified input stream and the
     * specified node factory.
     * @param istream the input stream 
     * @param factory the element factory used to create nodes
     */
    public XMLElementDeserializer(InputStream istream, 
				  XMLElementFactory factory) {
	this.istream = istream;
	this.factory = factory;
    }

    /**
     * Reads and returns the <code>XMLElement</code> from the xml document.
     * @exception SAXException Any SAX exception, possibly wrapping another
     * exception.
     * @exception ClassNotFoundException The SAX parser class was not found
     * (check your CLASSPATH).
     * @exception IllegalAccessException The SAX parser class was found, but
     * you do not have permission to load it.
     * @exception InstantiationException The SAX parser class was found but
     * could not be instantiated.
     * @exception IOException if an I/O error occured
     */
    public XMLElement readXMLElement() throws SAXException, 
                                              InstantiationException, 
					      ClassNotFoundException,
					      IllegalAccessException,
					      IOException {
	if (rootNode != null) {
	    return rootNode;
	}
	Parser parser = fr.dyade.koala.xml.sax.ParserFactory.makeParser();
	SAXHandler handler = new SAXHandler();
	parser.setDocumentHandler(handler);
	parser.setErrorHandler(handler);
	parser.parse(new InputSource(istream));
	this.rootNode = handler.root;
	return (XMLElement) handler.root.getChild(0);
    }
    
    /**
     * Closes the input stream.
     * @exception IOException if an I/O error occurs. In particular, an
     * IOException is thrown if the output stream is closed.  
     */
    public void close() throws IOException {
	istream.close();
    }

    /**
     * This class is a simple SAX handler that creates XMLNode objects.
     */
    private class SAXHandler extends HandlerBase implements ErrorHandler {

        private StringBuffer buffer = new StringBuffer();
        private XMLElement root = new XMLElement("root");
        private XMLElement current = root;
	private Hashtable stringCache = new Hashtable();

        public void startElement(String name, AttributeList atts) {
	    if (buffer.length() > 0) {
		current.appendChild(new XMLContent(new String(buffer)));
		buffer.setLength(0);
	    }
	    name = getCachedString(name);
	    // Creates the node using the factory
	    XMLElement node = factory.create(name);
	    // Sets the attributes of the node
            int size = atts.getLength();
            for (int i=0; i<size; i++) {
		String attrName = getCachedString(atts.getName(i));
		String attrValue = getCachedString(atts.getValue(i));
                node.addAttribute(attrName, attrValue);
            }
	    // Updates the current node
            current.appendChild(node);
            current = node;
        }

	private String getCachedString(String s) {
	    if (stringCache.containsKey(s)) {
		return (String) stringCache.get(s);
	    } else {
		stringCache.put(s, s);
		return s;
	    }
	}
	
        public void endElement(String name)    {
	    if (buffer.length() > 0) {
		current.appendChild(new XMLContent(new String(buffer)));
		buffer.setLength(0);
	    }
            current = current.getParent();
        }

        public void characters(char ch[],
                               int start,
                               int length) throws SAXException {
            buffer.append(ch, start, length);
        }

        public void endDocument () {
	    // Nothing to do
        }

        public void error(SAXParseException e) throws SAXException {
	    // Nothing to do
        }

        public void warning(SAXParseException e) throws SAXException {
            showMessage("\tWarning: ", e);
        }
    
        public void fatalError(SAXParseException e) throws SAXException {
            showMessage("\tFatal Error: ", e);
        }

	// Display a message, used by ErrorHandler
        private void showMessage(String kind, SAXParseException e) {
            System.err.println(" Line " + e.getLineNumber() 
                               + ":" + e.getColumnNumber());
            
            System.err.println("\t" + kind + ": " + e.getMessage());
            if (e.getException() != null) {
                e.getException().printStackTrace();
            } else {
		e.printStackTrace();
            }
        }
    }
}
