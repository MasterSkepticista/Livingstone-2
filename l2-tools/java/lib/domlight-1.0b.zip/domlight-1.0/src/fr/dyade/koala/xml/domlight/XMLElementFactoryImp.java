/*
 * DOM Light - Copyright (C) 1999 Dyade
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL Dyade BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dyade shall not be
 * used in advertising or otherwise to promote the sale, use or other
 * dealings in this Software without prior written authorization from
 * Dyade.
 *
 * $Id: XMLElementFactoryImp.java,v 1.2 1999/11/03 17:57:26 tkormann Exp $
 * Author: Thierry.Kormann@sophia.inria.fr
 */

package fr.dyade.koala.xml.domlight;

import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

/**
 * This factory enables to create standard <code>XMLElement</code> objects
 * using a property file. If the tag name is missing in the property file, a
 * simple <code>XMLElement</code> object is created.
 *
 * @author Thierry.Kormann@sophia.inria.fr 
 */
public class XMLElementFactoryImp implements XMLElementFactory {

    /** The properties. */
    protected Properties factory;

    /**
     * Constructs a new factory that uses the default property file.
     */
    public XMLElementFactoryImp() {
    }

    /**
     * Constructs a new factory that uses the specified property file.  
     * @param url the property file that describes for each tag, which class
     * the factory must instanciate depending on a specified tag
     */
    public XMLElementFactoryImp(URL url) {
        factory = new Properties();
        try {
            InputStream istream = url.openStream();
            factory.load(istream);
            istream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the properties this factory uses to instanciate XML nodes.
     */
    public Properties getProperties() {
	return factory;
    }

    /**
     * Creates an <code>XMLElement</code> or an <code>XMLElement</code>
     * subclass from the specified tag name. To create the node, the method
     * first search the tag name in the
     * <code>XMLElementFactory.properties</code> file to get the class of the
     * node to instanciate. Then if the associated class is not defined, the
     * method instanciate a simple <code>XMLElement</code>. At last the tag
     * name is set and the node returned.
     * @param name the name 
     */
    public XMLElement create(String name) {
	if (factory == null) {
	    return new XMLElement(name);
	}
	String className = factory.getProperty(name);
	if (className != null) {
	    try {
		Class nodeClass = Class.forName(className);
		XMLElement node = (XMLElement) nodeClass.newInstance();
		node.setName(name);
		return node;
	    } catch (Exception e) {
		e.printStackTrace();
	    } 
	}
	return new XMLElement(name);
    }
}
