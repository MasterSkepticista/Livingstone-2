/*
 * DOM Light - Copyright (C) 1999 Dyade
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL Dyade BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dyade shall not be
 * used in advertising or otherwise to promote the sale, use or other
 * dealings in this Software without prior written authorization from
 * Dyade.
 *
 * $Id: XMLElementSerializer.java,v 1.2 1999/11/03 17:57:26 tkormann Exp $
 * Author: Thierry.Kormann@sophia.inria.fr
 */

package fr.dyade.koala.xml.domlight;

import java.io.*;

/**
 * This class enables to create an XML document from an XMLElement.
 *
 * @author Thierry.Kormann@sophia.inria.fr 
 */
public class XMLElementSerializer {

    /** The output stream. */
    protected OutputStream ostream;

    /**
     * Constructs a new serializer with the specified output stream.
     * @param ostream the output stream used to write XML elements
     */
    public XMLElementSerializer(OutputStream ostream) {
	this.ostream = ostream;
    }

    /**
     * Writes the specified meta-data.
     * @param metaData the meta-data of the XML document
     * @exception IOException if an I/O error occurs
     */
    public void writeMetaData(String metaData) throws IOException {
	writeString(metaData);
    }

    /**
     * Writes the specified node.
     * @param node the element to write
     * @exception IOException if an I/O error occurs
     */
    public void writeXMLElement(XMLElement node) throws IOException {
	writeXMLNode(node);
    }

    // Write the specified node (XMLContent or XMLElement)
    private void writeXMLNode(XMLNode node) throws IOException {
	if (node instanceof XMLContent) {
	    XMLContent cnode = (XMLContent) node;
	    writeString(convertStringToXML(cnode.getContent()));
	} else {
	    XMLElement elem = (XMLElement) node;
	    // Writes the opening tag
	    writeString("<"+elem.getName());
	    // Writes its attributes
	    String [] names = elem.getAttributes();
	    if (names != null) {
		for (int i=0; i < names.length; ++i) {
		    String name = names[i];
		    String value=convertStringToXML(elem.getAttribute(name));
		    writeString(" "+name+"=\""+value+"\"");
		}
	    }
	    if (elem.getChildCount() == 0) {
		writeString("/>");
	    } else {
		writeString(">");
		// Writes its children
		for (int i=0; i < elem.getChildCount(); ++i) {
		    writeXMLNode(elem.getChild(i));
		}
		// Write the closing tag
		writeString("</"+elem.getName()+">");
	    }
	}
    }

    /**
     * Returns an XML version of the string.
     * @param s the string to convert
     */
    public static String convertStringToXML(String s) {
        if (s == null) {
	    return "";
	}
        int slength = s.length();
        StringBuffer result = new StringBuffer(slength);
        for (int i=0; i<slength; i++) {
            char c = s.charAt(i);
            switch (c) {
	    case '<': 
		result.append("&lt;"); 
		break;
	    case '>': 
		result.append("&gt;");   
		break;
	    case '&': 
		result.append("&amp;");   
		break;
	    case '"': 
		result.append("&quot;");  
		break;
	    case '\'': 
		result.append("&apos;"); 
		break;
	    default:
		if ((c == '\n') || (c == '\t') || (c == '\r'))
		    result.append(c);
		else if ((c < ' ') || (c > 127)) {
		    result.append("&#");
		    result.append(String.valueOf((int)c));
		    result.append(";");
		} else {
		    result.append(c);
		}
            }
        }
        return result.toString();
    }

    // Writes the specified String to the OutputStream
    private void writeString(String s) throws IOException {
	ostream.write(s.getBytes());
    }

    /**
     * Closes the output stream.
     * @exception IOException if an I/O error occurs. In particular, an
     * IOException is thrown if the output stream is closed.  
     */
    public void close() throws IOException {
	ostream.write('\n');
	ostream.close();
    }

    /**
     * Flushes this output stream.
     * @exception IOException if an I/O error occurs.  
     */
    public void flush() throws IOException {
	ostream.flush();
    }
}
