
import fr.dyade.koala.xml.domlight.*;

public class DynamicDOMUse {
    
    public static void main(String[] args) {
	// Creates the root node
	XMLElement root = new XMLElement();
	root.setName("html");
	// Adds some attributes
	root.addAttribute("class", "koala");
	root.addAttribute("foo",   "bar");
	// Adds some children
	XMLContent content = new XMLContent();
	content.setContent("koalas are small and ");
	root.appendChild(content);

	XMLElement bold = new XMLElement();
	bold.setName("b");
	bold.appendChild(content=new XMLContent());
	content.setContent("lazy ");
	root.appendChild(bold);

	root.appendChild(content=new XMLContent());
	content.setContent("animals ");
	root.appendChild(content);

	Util.print(root);
    }
}
