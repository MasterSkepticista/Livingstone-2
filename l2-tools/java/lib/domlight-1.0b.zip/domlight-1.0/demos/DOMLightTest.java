/* Copyright (c) 1999 by Groupe Bull. All Rights Reserved */
/* $Id: DOMLightTest.java,v 1.1.1.1 1999/11/03 14:40:32 phk Exp $ */
/* Author: Thierry.Kormann@sophia.inria.fr */

import java.io.*;
import fr.dyade.koala.xml.domlight.*;

public class DOMLightTest {

    public static void main(String[] args) throws Exception {
	// read
	System.out.println("--- deserialize ---");
	XMLElementDeserializer deser = new XMLElementDeserializer(
				           new FileInputStream(args[0]));
	XMLElement root = deser.readXMLElement();
	deser.close();
	System.out.println("--- serialize using System.out ---");
	XMLElementSerializer ser = new XMLElementSerializer(System.out);
	ser.writeXMLElement(root);
	System.out.println("\n");
	System.out.println("--- print node hierarchy ---");
	Util.print(root);
	System.out.println("\n");
	ser.flush();
    }
}
