See http://www.antlr.org/fieldguide/whitespace for a description of
this translator.

Peace,
Terence
