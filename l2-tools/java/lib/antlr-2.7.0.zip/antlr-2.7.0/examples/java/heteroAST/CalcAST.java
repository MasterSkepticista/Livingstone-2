public abstract class CalcAST extends antlr.BaseAST {
    public abstract int value();
}
