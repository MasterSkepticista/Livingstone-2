SAX 1.0: The Simple API for XML (Java Implementation)


SAX is a simple, common event-based API for XML parsers.  In addition
to this distribution, you need to download an XML parser, and possibly
also a third-party SAX driver if the parser does not come with SAX 1.0
support.

For a description of the files in the distribution, see ROADMAP.txt.

For the copyright and conditions of use (it's free), see COPYING.txt.

For much more documentation, visit the SAX home page at

  http://www.megginson.com/SAX/


Enjoy!


David Megginson <david@megginson.com>
